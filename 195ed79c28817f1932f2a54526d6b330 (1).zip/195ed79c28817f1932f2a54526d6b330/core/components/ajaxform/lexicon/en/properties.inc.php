<?php

$_lang['ajaxform_prop_form'] = 'Chunk with form for submit.';
$_lang['ajaxform_prop_snippet'] = 'Snippet, that will process specified form.';
$_lang['ajaxform_prop_frontend_css'] = 'File with css styles for frontend.';
$_lang['ajaxform_prop_frontend_js'] = 'File with javascript for frontend.';
$_lang['ajaxform_prop_actionUrl'] = 'Connector to handle ajax requests.';
$_lang['ajaxform_prop_formSelector'] = 'Еhe name of the CSS class that will be used as a jQuery selector to initialize the form. Default is "ajax_form".';
$_lang['ajaxform_prop_objectName'] = 'The name of the object to initialize in javascript. Default is "AjaxForm".';