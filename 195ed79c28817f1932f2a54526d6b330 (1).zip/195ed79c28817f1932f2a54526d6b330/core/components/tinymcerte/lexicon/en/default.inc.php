<?php
/**
 * Default Lexicon Entries for TinyMCE Rich Text Editor
 *
 * @package tinymcerte
 * @subpackage lexicon
 */
$_lang['tinymcerte'] = 'TinyMCE Rich Text Editor';
$_lang['tinymcerte.float_left'] = 'Left';
$_lang['tinymcerte.float_none'] = 'None';
$_lang['tinymcerte.float_right'] = 'Right';
$_lang['tinymcerte.select_none'] = '(None)';
$_lang['tinymcerte.select_resource'] = 'Select resource';
