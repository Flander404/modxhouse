--------------------
Extension: translit
--------------------
Version: 1.0.0-beta
Released: October 20, 2010
Since: October 20, 2010
Author: Jason Coward <jason@modx.com>

A MODx Revolution Core Extension, the translit package provides a custom transliteration service class. When installed,
this is automatically available for the core Friendly URL alias transliteration process for Resources. You can also use
the service in your plugins and snippets.